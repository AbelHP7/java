/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany._ejercicio331.pagina301;

/**
 *
 * @author usuario
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
